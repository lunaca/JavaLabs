package program3;

public interface Sounds {

	
	//Declarations
		public void play();
		public void print();
		public void setTitle(String title);
		public String getTitle();
	}

	
	
