
/////////////////ZACHARY BROOKS///////////////////////
/////////////////PROGRAM 2///////////////////////////
////////////////PALINDROME DETECTOR/////////////////





package program2;
import java.net.* ; 





public class Palindrome 

{
	
	//Original Sentence as entered by command
	private String sentence;

	//Each word based on delimiter
	private String[] words;

	//Single delimiter used for separating words
	private String delimiter;

	
	
	// Three Constructors

	public Palindrome()
	//Sets the sentence data field to the String “Every man for himself”, the delimiter should be a single space. The words data field array should contain the 4 words – Every man for himself.
	 
	{	//Construct sentence and delimiter
			String sample = "Every man for himself";
			this.sentence = sample.toLowerCase();
			this.delimiter = "[ ]+";
			System.out.println("YOUR TEST PALINDROME IS:" + sentence);
			
		////Create words
			int i = 0 ;
			int size = sentence.length();
			this.words = new String[size];
		
		////Split sentence by delimiter and put into words	
		
			this.words = sentence.split(this.delimiter);

		for(i = 0 ;i <words.length;i++ )
			{
			
				
				System.out.println(words[i]);
			}
			
		
}
	
	
	
	
	public Palindrome(String sentence)
	//Sets the sentence data field to the String contained in the formal parameter sentence. The assumption is that only those sentences that use the space delimiter will use this Constructor. The delimiter data field should be set to a space. The parameter sentence should be split into the separate words and each word should be stored in the array of words.
	{ 
		{	////Set Data Fields
			   this.sentence = sentence.toLowerCase();
			   this.delimiter = "[ ]+";
			   System.out.println("YOUR TEST PALINDROME IS: " + sentence );
			   
			////Create words
				int i = 0 ;
				int size = this.sentence.length();
				this.words = new String[size];
				this.words = sentence.split(this.delimiter);
			
			for(i = 0 ;i < words.length;i++ )
				
				{
					
					System.out.println(words[i]);
				}
				
		}
		
	}
	 


	public Palindrome(String sentence, String delimiter)
	//Sets the sentence data field to the String contained in the formal parameter sentence. The sentence will be split into words using the delimiter stored in the parameter delimiter.
	{
		{	//Set Data Fields 
			    this.sentence = sentence.toLowerCase();
			    this.delimiter = "["+(delimiter)+"]+";
			    System.out.println(this.delimiter);
				
			////Create words
			    int i = 0 ;
			    int size = this.sentence.length();
			    System.out.println("YOUR TEST PALINDROME IS: " + sentence);
			    this.words = new String[size];
				
			//Split into array
			    this.words = this.sentence.split(this.delimiter);
			
		   for(i = 0 ;i <words.length;i++ )
			   
		   		{
					
					System.out.println(words[i]);
				}
				
		}
	}
	/////////////////////////Getters/Setters

	public String getSentence()
	//Getter for sentence data field
	
	{
			return sentence;
	}
	
	
	public String getDelimiter() //Getter for delimiter data field
	{
			return delimiter;
	}
	
	
	public String getWordAt(int index)
	//Returns the String from the private data field words array stored at the subscript indicated by the input parameter index. 
	{		
			return words[index];
	}
	
	
	public void setSentence(String sentence)
	//Setter 
	{
			this.sentence = sentence;
	}
	
	
	public void setDelimiter(String delimiter)   //Setter for delimiter field
	{
			this.delimiter = delimiter;
	}

	public void reversible() //Detects if the words in a sentence are reversible – i.e., the original sentence is the same if the first word is switched with the last word, the 2nd word is switched with the next to last word, and so on. 
   {
			int size = words.length;
		
	
		/////If input is one, break with chord
			
			
		if(size == 1)
			{
			System.out.println("Of course a single word is a Palindrome. :)");
			AePlayWave ae = new AePlayWave( "./program2/chord.wav" );
			ae.play();
			return;
			}
		
		///Compares words side by side through a loop
		
		for(int i = 0; i < (size / 2); i++)
		
			{
			
			///// if its not a palindrome...
			
			
		if(!words[i].contentEquals(words[size - i - 1]))
		
			
			{
			System.out.println("This sentence is not a Palindrome.");
			AePlayWave ae = new AePlayWave( "./program2/WindowsCriticalStop.wav" );
			ae.play();
			
			
			return;
			
			}
			
			}
			///// if it is a palindrome...
		
		
			System.out.println("This sentence is a palindrome.");
			AePlayWave aw = new AePlayWave( "./program2/tada.wav" );
		    aw.play();    
		    
			return;
			
			
		
		
		
		
	}
	
	

	public static void main(String[] args)
	{
		//////First see the size of arguments
	
		int size = args.length;
	 
	       
	    //// choose what constructor to use and execute reversible
	    
	    if(size == 2)
	    	
	    {  
	    	String arg = args[0];
	    	String arg1 = args[1];
	    	Palindrome pali = new Palindrome(arg, arg1);
	    	pali.reversible();
	    	
	    }
	    
	    
	    
	    if(size == 1)
	    {
	    	Palindrome pali = new Palindrome(args[0]);
	    	pali.reversible();
	    }
	    
	    
	    
	    if(size == 0)
	    {
	    	Palindrome pali = new Palindrome();
	    	pali.reversible();
	    }
	
	    
	   
	
	}
	
	
	

}
