package program2;


import java.net.*;

 

public class AudioTest
{

  public AudioTest()
  {
    // TODO Auto-generated constructor stub
  }

  /**
   * @param args
   */
  public static void main(String[] args) 
  {
    // TODO Auto-generated method stub
    AePlayWave aw = new AePlayWave( "./program2/tada.wav" );
    aw.play();    
    
    
    return;
   
  }

}
