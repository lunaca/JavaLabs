///////////ZAC BROOKS///////////////////////////////
///////////B001089888/////////////////////////////
/////////O-O JAVA PROGRAM 1 //////////////////////////////////
/////////PROGRAM THAT SHOWS A PARALLEL ARRAY OF COUNTRY ATTRIBUTES WITHIN USER ARGUMENT PARAMETERS//////////





package program1;

public class CountryStats {
	
	 
	

	 
	 
	 public static void main(String[] args)
	 {
		 
		 	
			///first here are the countries!////////////////////////////////////
			
			String[] countries = {
				"Afghanistan",
		        "Albania",
		        "Algeria",
		        "American Samoa",
		        "Andorra",
		        "Angola",
		        "Anguilla",
		        "Antigua and Barbuda",
		        "Argentina",
		        "Armenia",
		        "Aruba",
		        "Australia",
		        "Austria",
		        "Azerbaijan",
		        "Bahamas",
		        "Bahrain",
		        "Bangladesh",
		        "Barbados",
		        "Belarus",
		        "Belgium",
		        "Belize",
		        "Benin",
		        "Bermuda",
		        "Bhutan",
		        "Bolivia",
		        "Bosnia",
		        "Botswana",
		        "Brazil",
		        "British Virgin Islands",
		        "Brunei",
		        "Bulgaria",
		        "Burkina Faso",
		        "Burundi",
		        "Cambodia",
		        "Cameroon",
		        "Canada",
		        "Cape Verde",
		        "Cayman Islands",
		        "Central African Republic",
		        "Chad",
		        "Chile",
		        "China",
		        "Christmas Island",
		        "Colombia",
		        "Comoros",
		        "Cook Islands",
		        "Costa Rica",
		        "Croatia",
		        "Cuba",
		        "Cyprus",
		        "Cyprus Northern",
		        "Czech Republic",
		        "Cte dIvoire",
		        "Democratic Republic of the Congo",
		        "Denmark",
		        "Djibouti",
		        "Dominica",
		        "Dominican Republic",
		        "Ecuador",
		        "Egypt",
		        "El Salvador",
		        "Equatorial Guinea",
		        "Eritrea",
		        "Estonia",
		        "Ethiopia",
		        "Falkland Islands",
		        "Faroe Islands",
		        "Fiji",
		        "Finland",
		        "France",
		        "French Polynesia",
		        "Gabon",
		        "Gambia",
		        "Georgia",
		        "Germany",
		        "Ghana",
		        "Gibraltar",
		        "Greece",
		        "Greenland",
		        "Grenada",
		        "Guam",
		        "Guatemala",
		        "Guinea",
		        "Guinea Bissau",
		        "Guyana",
		        "Haiti",
		        "Honduras",
		        "Hong Kong",
		        "Hungary",
		        "Iceland",
		        "India",
		        "Indonesia",
		        "Iran",
		        "Iraq",
		        "Ireland",
		        "Israel",
		        "Italy",
		        "Jamaica",
		        "Japan",
		        "Jordan",
		        "Kazakhstan",
		        "Kenya",
		        "Kiribati",
		        "Kuwait",
		        "Kyrgyzstan",
		        "Laos",
		        "Latvia",
		        "Lebanon",
		        "Lesotho",
		        "Liberia",
		        "Libya",
		        "Liechtenstein",
		        "Lithuania",
		        "Luxembourg",
		        "Macao",
		        "Macedonia",
		        "Madagascar",
		        "Malawi",
		        "Malaysia",
		        "Maldives",
		        "Mali",
		        "Malta",
		        "Marshall Islands",
		        "Martinique",
		        "Mauritania",
		        "Mauritius",
		        "Mexico",
		        "Micronesia",
		        "Moldova",
		        "Monaco",
		        "Mongolia",
		        "Montserrat",
		        "Morocco",
		        "Mozambique",
		        "Myanmar",
		        "Namibia",
		        "Nauru",
		        "Nepal",
		        "Netherlands",
		        "Netherlands Antilles",
		        "New Zealand",
		        "Nicaragua",
		        "Niger",
		        "Nigeria",
		        "Niue",
		        "Norfolk Island",
		        "North Korea",
		        "Norway",
		        "Oman",
		        "Pakistan",
		        "Palau",
		        "Panama",
		        "Papua New Guinea",
		        "Paraguay",
		        "Peru",
		        "Philippines",
		        "Pitcairn Islands",
		        "Poland",
		        "Portugal",
		        "Puerto Rico",
		        "Qatar",
		        "Republic of the Congo",
		        "Romania",
		        "Russian Federation",
		        "Rwanda",
		        "Saint Kitts and Nevis",
		        "Saint Lucia",
		        "Saint Pierre",
		        "Saint Vicent and the Grenadines",
		        "Samoa",
		        "San Marino",
		        "Sao Tom and Prncipe",
		        "Saudi Arabia",
		        "Senegal",
		        "Serbia and Montenegro",
		        "Seychelles",
		        "Sierra Leone",
		        "Singapore",
		        "Slovakia",
		        "Slovenia",
		        "Soloman Islands",
		        "Somalia",
		        "South Africa",
		        "South Georgia",
		        "South Korea",
		        "Soviet Union",
		        "Spain",
		        "Sri Lanka",
		        "Sudan",
		        "Suriname",
		        "Swaziland",
		        "Sweden",
		        "Switzerland",
		        "Syria",
		        "Taiwan",
		        "Tajikistan",
		        "Tanzania",
		        "Thailand",
		        "Tibet",
		        "Timor-Leste",
		        "Togo",
		        "Tonga",
		        "Trinidad and Tobago",
		        "Tunisia",
		        "Turkey",
		        "Turkmenistan",
		        "Turks and Caicos Islands",
		        "Tuvalu",
		        "UAE",
		        "Uganda",
		        "Ukraine",
		        "United Kingdom",
		        "United States of America",
		        "Uruguay",
		        "US Virgin Islands",
		        "Uzbekistan",
		        "Vanuatu",
		        "Vatican City",
		        "Venezuela",
		        "Vietnam",
		        "Wallis and Futuna",
		        "Yemen",
		        "Zambia",
		        "Zimbabwe"};
		    
			///then here is the area!!//////////////////////////////////////////
			
			double area[] = {
					250001.045000,
			        10578.422596,
			        919594.577480,
			        76.834298,
			        180.695736,
			        481353.363400,
			        25212.382404,
			        170.888745,
			        1056641.482380,
			        10965.296800,
			        74.517686,
			        2941298.008860,
			        31831.793288,
			        33243.382200,
			        3888.047140,
			        256.757830,
			        51702.918820,
			        166.409962,
			        80154.775200,
			        11690.396356,
			        8805.442212,
			        42710.603240,
			        20.579237,
			        18146.794000,
			        418685.147780,
			        19741.009158,
			        226012.527740,
			        3265075.424020,
			        59.073606,
			        2034.757540,
			        42683.576100,
			        105714.727600,
			        9903.516300,
			        68154.725040,
			        181251.722880,
			        3511021.239714,
			        1557.149366,
			        101.158724,
			        240535.368368,
			        486179.638400,
			        289113.177600,
			        3600945.553820,
			        52.123770,
			        401044.147400,
			        837.841340,
			        91.390343,
			        19559.927320,
			        21781.558228,
			        42803.267720,
			        3567.582480,
			        8231.930510,
			        29836.418152,
			        7.722040,
			        875524.895200,
			        16368.408188,
			        8872.623960,
			        291.120908,
			        18679.614760,
			        106888.477680,
			        384345.235900,
			        8000.033440,
			        10830.547202,
			        46841.894640,
			        16683.853522,
			        432311.845666,
			        4700.019646,
			        540.156698,
			        7054.083540,
			        117557.634246,
			        247125.743406,
			        1413.133320,
			        99485.744034,
			        3861.020000,
			        26911.309400,
			        134835.698746,
			        89166.395880,
			        2.509663,
			        50502.141600,
			        836330.136772,
			        132.819088,
			        208.997013,
			        41865.039860,
			        94925.879414,
			        10810.856000,
			        76004.178700,
			        10640.971120,
			        43200.952780,
			        402.318284,
			        35652.658680,
			        38706.725500,
			        1147954.605380,
			        705192.136880,
			        631662.872000,
			        166858.612524,
			        26598.566780,
			        7849.453660,
			        113521.710040,
			        4181.870762,
			        144689.407888,
			        35510.187042,
			        1030815.119600,
			        219788.563500,
			        313.128722,
			        6880.337640,
			        73861.312600,
			        89112.341600,
			        24551.840078,
			        3949.823460,
			        11720.126210,
			        37189.344640,
			        679361.913080,
			        61.776320,
			        39.382404,
			        998.459772,
			        68.726156,
			        9596.951312,
			        224533.757080,
			        36324.476160,
			        126853.812100,
			        115.830600,
			        471044.440000,
			        122.008232,
			        70.000293,
			        409.268120,
			        397839.500800,
			        783.787060,
			        742489.590080,
			        271.043604,
			        12884.609842,
			        0.752899,
			        428179.239,
			        39.382404,
			        172317.322600,
			        302738.717180,
			        8301.965204,
			        318695.540636,
			        8.108142,
			        55282.470462,
			        13082.294066,
			        370.657920,
			        103483.444142,
			        46430.309908,
			        489075.403400,
			        351649.346336,
			        100.386520,
			        13.359129,
			        46490.541820,
			        118703.971084,
			        82031.230920,
			        300665.349440,
			        176.834716,
			        29339.890980,
			        174850.151720,
			        153398.324600,
			        494210.560000,
			        115124.033340,
			        18.146794,
			        117554.545430,
			        35502.465002,
			        3424.724740,
			        4415.848574,
			        819059.022108,
			        88934.734680,
			        6562112.371600,
			        9632.472696,
			        100.772622,
			        233.977812,
			        93.436684,
			        150.193678,
			        1132.823268,
			        23.629442,
			        386.488102,
			        829999.608380,
			        74131.584000,
			        39434.913872,
			        175.676410,
			        27652.625240,
			        263.591835,
			        18841.777600,
			        7780.341402,
			        10633.249080,
			        242216.070374,
			        471010.463024,
			        1506.956106,
			        37911.355380,
			        10422905.343624,
			        192874.165284,
			        24996.243480,
			        917378.352000,
			        62343.889940,
			        6642.112706,
			        158662.439268,
			        15355.276540,
			        71062.073100,
			        12455.650520,
			        55096.755400,
			        342100.657774,
			        197595.420540,
			        54522.235624,
			        5407.18,
			        20998.157270,
			        277.221236,
			        1979.931056,
			        59984.806720,
			        297591.977520,
			        188456.386200,
			        166.023860,
			        10.038652,
			        32278.127200,
			        77108.430420,
			        233089.777400,
			        93278.382180,
			        3537436.794146,
			        67035.029240,
			        133.591292,
			        164247.790800,
			        4710.444400,
			        0.169885,
			        340561.269100,
			        125622.146720,
			        105.791948,
			        203850.272940,
			        285995.017848,
			        149294.060340 };
			
			//Then here are the populations/////////////////////////////////////
			
			 int pop[] = {
					 
					 	31889923,
				        3600523,
				        33333216,
				        57663,
				        71822,
				        12263596,
				        13677,
				        69481,
				        40301927,
				        2971650,
				        100018,
				        20434176,
				        8199783,
				        8120247,
				        305655,
				        708573,
				        150448339,
				        280946,
				        9724723,
				        10392226,
				        294385,
				        8078314,
				        66163,
				        2327849,
				        9119152,
				        4552198,
				        1815508,
				        190010647,
				        23552,
				        374577,
				        7322858,
				        14326203,
				        8390505,
				        13995904,
				        18060382,
				        33390141,
				        423613,
				        46600,
				        4369038,
				        9885661,
				        16284741,
				        1321851888,
				        1402,
				        44379598,
				        711417,
				        21750,
				        4133884,
				        4493312,
				        11394043,
				        788457,
				        68251,
				        10228744,
				        2114,
				        3800610,
				        5468120,
				        496374,
				        72386,
				        9365818,
				        13755680,
				        80335036,
				        6948073,
				        551201,
				        4906585,
				        1315912,
				        76511887,
				        3105,
				        47511,
				        918675,
				        5238460,
				        58772124,
				        278963,
				        1454867,
				        1688359,
				        4646003,
				        82400996,
				        22931299,
				        27967,
				        10706290,
				        56344,
				        89971,
				        173456,
				        12728111,
				        9947814,
				        1472780,
				        769095,
				        8706497,
				        7483763,
				        6980412,
				        9956108,
				        301931,
				        1129866154,
				        234693997,
				        65397521,
				        27499638,
				        4109086,
				        6426679,
				        58147733,
				        2780132,
				        127433494,
				        6053193,
				        15284929,
				        36913721,
				        107817,
				        2505559,
				        5284149,
				        6521998,
				        2259810,
				        3925502,
				        2125262,
				        3195931,
				        6036914,
				        34247,
				        3575439,
				        480222,
				        23124,
				        2055915,
				        19448815,
				        13603181,
				        24821286,
				        369031,
				        11995402,
				        401880,
				        61815,
				        436131,
				        3270065,
				        1250882,
				        108700891,
				        107862,
				        4320490,
				        32671,
				        2951786,
				        9538,
				        33757175,
				        20905585,
				        421541,
				        2055080,
				        13528,
				        28901790,
				        16570613,
				        223652,
				        4115771,
				        5675356,
				        12894865,
				        135031164,
				        1492,
				        2114,
				        23301725,
				        4627926,
				        3204897,
				        164741924,
				        20842,
				        3242173,
				        5795887,
				        6669086,
				        28674757,
				        91077287,
				        48,
				        38518241,
				        10642836,
				        3944259,
				        907229,
				        65751512,
				        22276056,
				        141377752,
				        9907509,
				        39349,
				        170649,
				        7036,
				        118149,
				        214265,
				        29615,
				        199579,
				        27601038,
				        12521851,
				        10832545,
				        81895,
				        6144562,
				        4553009,
				        5447502,
				        2009245,
				        566842,
				        9118773,
				        43997828,
				        0,
				        49044790,
				        300232187,
				        40448191,
				        20926315,
				        39379358,
				        470784,
				        1133066,
				        9031088,
				        7554661,
				        19314747,
				        22858872,
				        7076598,
				        39384223,
				        65068149,
				        4587212,
				        1084971,
				        5701579,
				        116921,
				        1056608,
				        10276158,
				        71158647,
				        5097028,
				        21746,
				        11992,
				        4444011,
				        30262610,
				        46299862,
				        60776238,
				        301139947,
				        3460607,
				        108448,
				        27780059,
				        211971,
				        821,
				        26023528,
				        85262356,
				        16309,
				        22230531,
				        11477447,
				        12311143};
			
			 
			 
			 ////////////Set String versions of arguments read in////////////////
			 
			String ignore = "I";
			
			String arg0 = args[0];
			String arg1 = args[1];
			String arg2 = args[2];
			String arg3 = args[3];
			String arg4 = args[4];
			String arg5 = args[5];
			
			
			/////////////////////initialize parameters//////////////////////////////////////
			
			
			
			double lowAreaValue = 0;
			double highAreaValue = 0;
			double lowPopValue = 0;
			double upPopValue = 0;
			double highDensityValue = 0;
			double lowDensityValue = 0;
		
			
			
			
			System.out.println("Displaying List of Countries With Attributes Between:");
			
			
			//////////////check for ignore values and set parameters///////////////////////////
			
			
			
			if(arg0.contains(ignore) == true ) 
			{ lowAreaValue = 0;}
		
			else{ lowAreaValue = Double.parseDouble(args[0]);}
			
			System.out.println("AREA HIGHER THAN:");
			System.out.println(lowAreaValue);
					
			

		  if(arg1.contains(ignore) == true ) 
			 {highAreaValue = 10000000000.00;}
			 else 
			 { highAreaValue = Double.parseDouble(args[1]);}
		  
		  System.out.println("AREA LOWER THAN:");
		  System.out.println(highAreaValue);	  
		  
		  
		  if(arg2.contains(ignore) == true ) 
			 {lowPopValue = 0;}
			 else 
			{ lowPopValue = Double.parseDouble(args[2]);}
		  
		  System.out.println("POPULATION HIGHER THAN:");
		  System.out.println(lowPopValue);
		  
		  
		  
		  if(arg3.contains(ignore) == true ) 
			 {upPopValue = 10000000000.00;}
			 else 
			 { upPopValue = Double.parseDouble(args[3]);}
		  
		  System.out.println("POPULATION LOWER THAN:");
		  System.out.println(upPopValue);
		  
		  

		  if(arg4.contains(ignore) == true ) 
			 {lowDensityValue = 0;}
			 else 
			 { lowDensityValue = Double.parseDouble(args[4]);}
			 
		  System.out.println("DENSITY HIGHER THAN:");
		  System.out.println(lowDensityValue);
		  
		  
		  
		  if(arg5.contains(ignore) == true ) 
			 {highDensityValue = 10000000000.00;}
			 else 
			 { highDensityValue = Double.parseDouble(args[5]);}
			
		  System.out.println("DENSITY LOWER THAN:");
		  System.out.println(highDensityValue);
		
		  
		  //Then Create density///////////////////////////////////////////////////////
		 
			 
			 double [] density = new double[area.length]; 
			 
			 
			 for( int i = 0; i < area.length; i++ )
				 
			 {
				 
				density[i] = pop[i] / area[i];
				
			 
			 };
			 
			 //Set up display
			 System.out.format("|%30s|", "COUNTRIES");
			 System.out.format("|%30s|", "AREA");
			 System.out.format("|%30s|", "POPULATION");
			 System.out.println("DENSITY");
			 
		 //Fly through the array and print the entries that qualify. ////////////////////
			 
			 
			 for( int i = 0; i < area.length; i++ )
			 {
				 if((density[i] > lowDensityValue)&&(density[i] < highDensityValue)&&(area[i] >lowAreaValue) &&(area[i] < highAreaValue)&&(pop[i] > lowPopValue)&&(pop[i] < upPopValue))
					
					 {System.out.format("|%30s|",countries[i]);
					 System.out.format("|%30s|", area[i]);
					 System.out.format("|%30s|",pop[i]);
					 System.out.println(density[i]);
					 }
				 
				 
				 	
					 
				 
				 
			 } 
				 
				 
			 }
			
		 
			
				                                                 
			 
	 
	 
	 
	 
	 
	 
	 
	 
	 
}
